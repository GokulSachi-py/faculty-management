module.exports = {
    // Email configuration moved to environment variables
    email: {
        user: 'godofstorm0509@gmail.com',
        pass: 'wluvqfvdynnxhnbu'
    }
}; 